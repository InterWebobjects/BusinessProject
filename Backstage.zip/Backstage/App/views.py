from django.shortcuts import render


# Create your views here.

# 主页
from App.models import User


def index(request):
    return render(request, 'index.html')


# 桌面
def welcome(request):
    # if request.GET.get('memberlist'):
    #     return render(request, 'member-list.html', locals())

    return render(request, 'videoQuery.html')


# 会员
def users(request):

    return render(request, 'studentdetail.html')

#用户
def students(request):
    uses=User.objects.all()

    return render(request, 'studentQuery.html',locals())

#分类
def category(request):
    return render(request,'classQuery.html')


#添加大类
def category_add(request):
    if request.method =='POST':
        if request.POST.get('small'):



            return render(request,'subjectQuery.html',locals())

    return render(request,'classAdd.html')

#添加小类
def category_small(request):
    if request.method =='POST':
        if request.POST.get('add_small'):


            return render(request, 'subjectAdd.html')


def login(request):
    return render(request,'login.html')