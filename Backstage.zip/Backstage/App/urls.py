from django.conf.urls import url

from App import views

urlpatterns = [

    url(r'^$', views.index, name='index'),
    url(r'^welcome/$', views.welcome, name='welcome'),
    url(r'^users/$', views.users, name='users'),
    url(r'^student/$',views.students,name='students'),
    url(r'^category/$',views.category,name='category'),
    url(r'^category_add/$',views.category_add,name='category_add'),
    url(r'^category_small/$',views.category_small,name='category_small'),
    url(r'^login$',views.login,name='login'),
]
